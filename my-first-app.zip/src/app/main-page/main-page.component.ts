import { Component, signal } from '@angular/core';
import { OreTapComponent } from '../ore-tap/ore-tap.component';
import { OreConverterComponent } from '../ore-converter/ore-converter.component';
import { CommonModule } from '@angular/common';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { OrexService } from '../services/orex.service';  // Импорт сервиса

@Component({
  selector: 'app-main-page',
  standalone: true,
  imports: [CommonModule, OreTapComponent, OreConverterComponent, MatProgressBarModule],
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.scss']
})
export class MainPageComponent {
  totalOrex = signal(0);  // Сигнал для хранения Orex
  totalXiom = signal(0);  // Сигнал для хранения Xiom

// Внедрение OrexService в конструктор
  constructor(private orexService: OrexService) {}

  sendProgressToServer(newProgress: number) {
    const telegramId = 'айди игрока'; // Здесь будет ID игрока
    this.orexService.updateProgress(telegramId, newProgress).subscribe(response => {
      console.log('Прогресс обновлен:', response);
    });
  }

  ngOnInit() {
    if (typeof window !== 'undefined' && window.Telegram && window.Telegram.WebApp) {
      window.Telegram.WebApp.init();
      const userData = window.Telegram.WebApp.initDataUnsafe.user;

      if (userData) {
        console.log('Данные пользователя получены:', userData);
      } else {
        console.log('Не удалось получить данные о пользователе');
      }
    } else {
      console.log('Telegram WebApp не найден или не запущен на клиенте');
    }
  }



  // Метод для увеличения Orex при нажатии на камень
  handleOreTap() {
    this.totalOrex.update(value => value + 1);
  }

  // Метод для конвертации Orex в Xiom
  handleConvert() {
    if (this.totalOrex() >= 10) {
      this.totalOrex.update(value => value - 10);
      this.totalXiom.update(value => value + 1);
    }
  }
}
