import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  constructor(private http: HttpClient) {}

  // Метод для синхронизации данных пользователя с сервером
  syncUser(telegramId: string): Observable<any> {
    const url = 'http://localhost:3000/api/sync-user';  // URL вашего API
    return this.http.post(url, { telegramId });
  }

  // Метод для обновления прогресса на сервере
  updateProgress(telegramId: string, progress: number): Observable<any> {
    const url = 'http://localhost:3000/api/update-progress';  // URL для обновления прогресса
    return this.http.post(url, { telegramId, progress });
  }
}
