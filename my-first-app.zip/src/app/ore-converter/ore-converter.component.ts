import { Component, Input, signal, WritableSignal } from '@angular/core';

@Component({
  selector: 'app-ore-converter',
  standalone: true,
  imports: [],
  templateUrl: './ore-converter.component.html',
  styleUrls: ['./ore-converter.component.scss']
})
export class OreConverterComponent {
  @Input() orex: number = 0;  // Получаем количество Orex из родительского компонента
  @Input() xiom: number = 0;  // Передаем количество Xiom из родительского компонента

  // Метод обработки клика для конвертации
  onConvertClick() {
    if (this.orex >= 10) {
      this.orex -= 10;  // Уменьшаем количество Orex на 10
      this.xiom += 1;  // Увеличиваем количество Xiom на 1
    }
  }
}
