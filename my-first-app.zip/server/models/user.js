const mongoose = require('mongoose');

// Описание схемы данных пользователя
const userSchema = new mongoose.Schema({  // Изменили UserSchema на userSchema
  telegramId: String,
  firstName: String,
  lastName: String,
  username: String,
  orex: {
    type: Number,
    default: 0,  // Изначально 0 Orex
  },
  xiom: {
    type: Number,
    default: 0,  // Изначально 0 Xiom
  }
});

// Создание модели пользователя на основе схемы
const User = mongoose.model('User', userSchema);

module.exports = User;
