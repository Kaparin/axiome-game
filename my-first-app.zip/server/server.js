const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const mongoose = require('mongoose'); // Подключаем mongoose для работы с MongoDB
const orexRoutes = require('./routes/orex'); // Подключаем маршрут для Orex

const app = express();
const port = 3000;
app.use((req, res, next) => {
  console.log('Запрос от клиента:', req.method, req.url);
  next();
});

require('dotenv').config();
const BOT_TOKEN = process.env.BOT_TOKEN;
const MONGO_URI = process.env.MONGO_URI;

// Подключение к MongoDB
mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB подключен'))
  .catch(err => console.log('Ошибка подключения к MongoDB:', err));

// Настройка сервера для обработки данных от Telegram
app.use(bodyParser.json());
app.use('/api/orex', orexRoutes); // Используем роут для orex

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});
